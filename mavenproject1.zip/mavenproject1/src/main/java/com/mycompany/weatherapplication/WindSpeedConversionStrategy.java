
package com.mycompany.weatherapplication;

interface WindSpeedConversionStrategy {
    double convert(double windSpeed);
}
