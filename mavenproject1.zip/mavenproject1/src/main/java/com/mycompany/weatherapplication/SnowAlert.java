
package com.mycompany.weatherapplication;


class SnowAlert extends WeatherAlert {
    public void displayAlert() {
        System.out.println("Warning: Snow Alert!");
    }
}