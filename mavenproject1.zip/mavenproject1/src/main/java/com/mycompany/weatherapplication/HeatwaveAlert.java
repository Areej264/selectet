
package com.mycompany.weatherapplication;

class HeatwaveAlert extends WeatherAlert {
    public void displayAlert() {
        System.out.println("Warning: Heatwave Alert!");
    }
}