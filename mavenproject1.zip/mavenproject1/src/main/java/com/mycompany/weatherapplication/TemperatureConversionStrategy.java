
package com.mycompany.weatherapplication;

interface TemperatureConversionStrategy {
    double convert(double temperature);
}