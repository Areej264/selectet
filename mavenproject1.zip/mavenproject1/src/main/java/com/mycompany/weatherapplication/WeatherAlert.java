
package com.mycompany.weatherapplication;
public abstract class WeatherAlert {
    public abstract void displayAlert();
}