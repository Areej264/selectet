
package com.mycompany.weatherapplication;

class GeneralAlert extends WeatherAlert {
    public void displayAlert() {
        System.out.println("Weather alert: No specific alerts.");
    }
}