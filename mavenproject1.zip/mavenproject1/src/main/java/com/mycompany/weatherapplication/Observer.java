package com.mycompany.weatherapplication;

public interface Observer {
    void update(String message);
}
