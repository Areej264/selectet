
package com.mycompany.weatherapplication;

class StormAlert extends WeatherAlert {
    public void displayAlert() {
        System.out.println("Warning: Storm Alert!");
    }
}
